<?php
header('Content-Type: application/json');
require_once '../shared/users.php';

if (isset($_GET['id'])) {
    $id = (int) $_GET['id'];
    echo isset($users[$id]) ? json_encode($users[$id]) : json_encode(['error' => 'User not found']);
} else {
    echo json_encode(array_values($users));
}

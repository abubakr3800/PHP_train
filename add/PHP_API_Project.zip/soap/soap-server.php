<?php
require_once '../shared/users.php';

class UserService {
    public function getUser($id) {
        global $users;
        return isset($users[$id]) ? $users[$id] : null;
    }
}

ini_set("soap.wsdl_cache_enabled", "0");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    echo "SOAP Server is running...";
} else {
    $server = new SoapServer(null, ['uri' => 'http://localhost']);
    $server->setClass('UserService');
    $server->handle();
}

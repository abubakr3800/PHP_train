<?php
$client = new SoapClient(null, [
    'location' => 'http://localhost/PHP_API_Project/soap/soap-server.php',
    'uri' => 'http://localhost'
]);

$response = $client->getUser(1);
echo "<pre>";
print_r($response);

<?php
$siteName = "موقعي الشخصي";
$skills = ["HTML", "CSS", "PHP", "Laravel"];
?>

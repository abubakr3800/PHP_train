<ul>
<?php foreach ($skills as $skill): ?>
  <li><?= $skill; ?></li>
<?php endforeach; ?>
</ul>

<?php
$students = ["Ahmed", "Sara", "Laila", "Omar", "Nada"];
foreach ($students as $name) {
  echo $name . "<br>";
}

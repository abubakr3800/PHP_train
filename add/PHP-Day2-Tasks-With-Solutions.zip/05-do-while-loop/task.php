<?php
$attempt = 1;
do {
  echo "مرحبا!<br>";
  $attempt++;
} while ($attempt <= 3);

<?php
$grade = 85;
if ($grade >= 80) {
  echo "جيد جدًا";
}

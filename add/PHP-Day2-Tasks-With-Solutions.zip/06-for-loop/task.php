<?php
for ($i = 1; $i <= 10; $i++) {
  echo "7 × $i = " . (7 * $i) . "<br>";
}

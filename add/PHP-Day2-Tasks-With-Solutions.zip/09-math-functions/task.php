<?php
$num = 4.8;
echo "Ceil: " . ceil($num) . "<br>";
echo "Floor: " . floor($num) . "<br>";
echo "Sqrt: " . sqrt(64) . "<br>";
echo "Max: " . max(3, 10, 25) . "<br>";

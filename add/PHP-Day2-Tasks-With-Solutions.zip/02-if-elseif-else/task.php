<?php
$score = 45;
if ($score >= 90) {
  echo "ممتاز";
} elseif ($score >= 75) {
  echo "جيد جدًا";
} elseif ($score >= 50) {
  echo "ناجح";
} else {
  echo "راسب";
}

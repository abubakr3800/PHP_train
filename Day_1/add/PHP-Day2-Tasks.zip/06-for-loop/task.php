<?php
// Task: 06 For Loop

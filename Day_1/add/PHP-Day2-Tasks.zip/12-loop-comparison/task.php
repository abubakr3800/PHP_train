<?php
// Task: 12 Loop Comparison

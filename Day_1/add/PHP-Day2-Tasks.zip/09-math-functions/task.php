<?php
// Task: 09 Math Functions

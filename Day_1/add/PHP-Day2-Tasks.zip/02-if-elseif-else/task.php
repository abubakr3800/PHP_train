<?php
// Task: 02 If Elseif Else

<?php
// Task: 11 Foreach With Condition

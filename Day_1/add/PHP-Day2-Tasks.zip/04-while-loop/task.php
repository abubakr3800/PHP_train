<?php
// Task: 04 While Loop

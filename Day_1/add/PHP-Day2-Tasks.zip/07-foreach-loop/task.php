<?php
// Task: 07 Foreach Loop

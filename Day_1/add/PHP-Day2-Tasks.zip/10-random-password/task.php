<?php
// Task: 10 Random Password

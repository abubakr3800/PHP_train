<?php
// Task: 03 Switch
